This package contains the Bitstream Vera font family, converted to
fft and fdb (Flash) format so you can use them with Ming.

The home page for these fonts can be found here:

http://www.gnome.org/fonts/

You are legally allowed to use these fonts as desired (commercially,
non-commercially, etc) provided you comply with the conditions
described in the COPYRIGHT.TXT file (included).

If you have any queries regarding the fonts themselves, or the
copyright terms, please refer to the COPYRIGHT.TXT file, or the
homepage.

If you have queries regarding how to use the fonts with Ming,
please refer to the Ming home page and go from there.

http://ming.sf.net

Good luck!  :)

 + The Ming Development Team

