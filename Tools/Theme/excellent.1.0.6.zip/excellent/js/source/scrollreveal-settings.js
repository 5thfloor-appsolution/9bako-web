
	// sl settings for animation effect.
jQuery( function() {
	var config = {
		scale: { power: '0%' },
		over: '1s',
		wait: '0.1s',
		move: '200px'
	}

	new scrollReveal(config);
} );