( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#easy-commerce-settings-metabox-container' ).tabs();

	});

} )( jQuery );
